from kafka import KafkaConsumer
import pandas as pd
import json
from cleaning import clean_stream_processing  
from db import save_row_to_db 

TABLE_NAME = 'fintech_data_52_MET_P1_24625_clean'

def consume_kafka_stream():
    # Initialize Kafka consumer
    consumer = KafkaConsumer(
        'de_ms2_52_24625',
        bootstrap_servers='kafka:9092',
        auto_offset_reset='latest',
        value_deserializer=lambda x: json.loads(x.decode('utf-8'))
    )
    print("Listening for messages in 'de_ms2_52_24625'...")

    empty_poll_limit = 5
    empty_poll_count = 0

    while True:
        message = consumer.poll(timeout_ms=2000)
        if message:
            empty_poll_count = 0  # Reset count when a message arrives
            for tp, messages in message.items():
                for msg in messages:
                    data = msg.value
                    if data == 'EOF':
                        print("Received EOF. Stopping consumer.")
                        consumer.close()
                        return
                    
                    # Convert the message into a DataFrame row
                    new_row = pd.DataFrame([data], columns=[
                        'customer_id', 'emp_title', 'emp_length', 'home_ownership',
                        'annual_inc', 'annual_inc_joint', 'verification_status', 'zip_code',
                        'addr_state', 'avg_cur_bal', 'tot_cur_bal', 'loan_id', 'loan_status',
                        'loan_amount', 'state', 'funded_amount', 'term', 'int_rate', 'grade',
                        'issue_date', 'pymnt_plan', 'type', 'purpose', 'description'
                    ])
                    
                    cleaned_row = clean_stream_processing(new_row) 
                    
                    save_row_to_db(cleaned_row, TABLE_NAME)
                    print(f"Saved cleaned row to database table '{TABLE_NAME}'")

        else:
            empty_poll_count += 1
            print("No messages received, polling again...")

            if empty_poll_count >= empty_poll_limit:
                print("No messages after multiple polls. Exiting.")
                break
