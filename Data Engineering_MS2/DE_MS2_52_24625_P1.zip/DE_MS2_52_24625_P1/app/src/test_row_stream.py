from cleaning import load_csv, clean_stream_processing
import pandas as pd

# Sample data
data = {
    'Customer Id': ['YidceGQxXHg4ZlwnXHhjYlx4YTRceDA4XHgwYlx4OGRceGE4XHhlNW5ceGY5XHRceGQ5YVx4ZTNceGRjMEhuXHg5M1x4YTVceDFiIixRXHhjNlx4YzhceGYxW2BceGJkJw=='],
    'Emp Title': ['Registered Nurse'],
    'Emp Length': ['8 years'],
    'Home Ownership': ['RENT'],
    'Annual Inc': [85000.0],
    'Annual Inc Joint': [None],
    'Verification Status': ['Not Verified'],
    'Zip Code': ['891xx'],
    'Addr State': ['NV'],
    'Avg Cur Bal': [4336.0],
    'Tot Cur Bal': [60710.0],
    'Loan Id': [193327],
    'Loan Status': ['Fully Paid'],
    'Loan Amount': [20000.0],
    'State': ['NV'],
    'Funded Amount': [20000.0],
    'Term': ['36 months'],
    'Int Rate': [0.1249],
    'Grade': [7],
    'Issue Date': ['14 March 2014'],
    'Pymnt Plan': ['False'],
    'Type': ['INDIVIDUAL'],
    'Purpose': ['credit_card'],
    'Description': ['Credit card refinancing']
}

# Create DataFrame
df = pd.DataFrame(data)

# Clean the data and get the lookup table
cleaned_row, lookup_table = clean_stream_processing(df)

# Display original, cleaned row, and lookup table
print("> Original DataFrame:")
print(df)
print("\n> Lookup Table:")
print(lookup_table)
print("\n> Cleaned Row DataFrame:")
print(cleaned_row)

# Save the cleaned row and lookup table to CSV files
cleaned_row.to_csv('cleaned_row_output.csv', index=False)
lookup_table.to_csv('lookup_table_output.csv', index=False)

print("\n> Cleaned row and lookup table have been saved as 'cleaned_row_output.csv' and 'lookup_table_output.csv'")
