from sqlalchemy import create_engine

engine = create_engine('postgresql://root:root@pgdatabase:5432/MS2_MET_P1_52_24625')

def save_to_db(cleaned,table_name):
    if(engine.connect()):
        print('Connected to Database')
        try:
            print('Writing cleaned dataset to database')
            cleaned.to_sql(table_name, con=engine, if_exists='fail')
            print('Done writing to database')
        except ValueError as vx:
            print('Cleaned Table already exists.')
        except Exception as ex:
            print(ex)
    else:
        print('Failed to connect to Database')


def save_row_to_db(row, table_name):

    if engine.connect():
        try:
            row.to_sql(table_name, con=engine, if_exists='append', index=False)
            print(f"> Successfully saved row to table '{table_name}'")
        except Exception as ex:
            print(f"Error while saving row: {ex}")
    else:
        print('Failed to connect to Database')
