print('> Starting...')

import os
import pandas as pd
from cleaning import clean , load_csv
from db import  save_to_db

# DATA_PATH='app/data/fintech_data_2_52_24625.csv'
# CLEANED_CSV = "app/data/fintech_data_MET_P1_52-24625_clean.csv"
# LOOKUP_CSV = "app/data/lookup_fintech_data_MET_P1_52-24625.csv"
# DESCRIPTION_MULTIVARIATE_LOOKUP_CSV = "app/data/description_multivariate_lookup_fintech_data_MET_P1_52-24625.csv"
# INT_RATE_MULTIVARIATE_LOOKUP_CSV = "app/data/int_rate_multivariate_lookup_fintech_data_MET_P1_52-24625.csv"
# EMP_TITLE_MULTIVARIATE_LOOKUP_CSV = "app/data/emp_title_multivariate_lookup_fintech_data_MET_P1_52-24625.csv"
# EMP_LENGTH_MULTIVARIATE_LOOKUP_CSV = "app/data/emp_length_multivariate_lookup_fintech_data_MET_P1_52-24625.csv"

DATA_PATH='data/fintech_data_2_52_24625.csv'
CLEANED_CSV = "data/fintech_data_MET_P1_52-24625_clean.csv"
LOOKUP_CSV = "data/lookup_fintech_data_MET_P1_52-24625.csv"
DESCRIPTION_MULTIVARIATE_LOOKUP_CSV = "data/description_multivariate_lookup_fintech_data_MET_P1_52-24625.csv"
INT_RATE_MULTIVARIATE_LOOKUP_CSV = "data/int_rate_multivariate_lookup_fintech_data_MET_P1_52-24625.csv"
SCALING_LOOKUP_TABLE_CSV = "data/scaling_lookup_fintech_data_MET_P1_52-24625.csv"
ONE_HOT_LOOKUP_TABLE_CSV = "data/one_hot_lookup_fintech_data_MET_P1_52-24625.csv"
EMP_TITLE_MULTIVARIATE_LOOKUP_CSV = "data/emp_title_multivariate_lookup_fintech_data_MET_P1_52-24625.csv"
EMP_LENGTH_MULTIVARIATE_LOOKUP_CSV = "data/emp_length_multivariate_lookup_fintech_data_MET_P1_52-24625.csv"

CLEANED_DATA_SET = "fintech_data_MET_P1_52-24625_clean"
LOOKUP = "lookup_fintech_data_MET_P1_52-24625"
INT_RATE_MULTIVARIATE_LOOKUP = "int_rate_multivariate_lookup_fintech_data_MET_P1_52-24625"
SCALING_LOOKUP_TABLE = "scaling_lookup_fintech_data_MET_P1_52-24625"
ONE_HOT_LOOKUP_TABLE = "one_hot_lookup_fintech_data_MET_P1_52-24625"


def load_csv_with_default_na_values(file_path):
    print("> Load CSV Dataframe")
    na_values = ['NA', 'Missing', 'NaN', '', ' ', 'null', 'None', 'N/A', 'n/a', 'UNKNOWN', 'unknown', 'undefined']
    df = pd.read_csv(file_path, na_values=na_values)
    return df
def save_csv(df, filename):
    df.to_csv(filename, index=False)
    print(f"> Saved DataFrame to {filename}")

def main():

    if os.path.exists(CLEANED_CSV):
        cleaned_df = load_csv(CLEANED_CSV)
        lookup_df = load_csv(LOOKUP_CSV)
        imputation_lookup_df_int_rate = load_csv(INT_RATE_MULTIVARIATE_LOOKUP_CSV)
        scaling_lookup_table = load_csv(SCALING_LOOKUP_TABLE_CSV)
        one_hot_lookup_table = load_csv(ONE_HOT_LOOKUP_TABLE_CSV)

        save_to_db(cleaned_df,CLEANED_DATA_SET)
        save_to_db(lookup_df,LOOKUP)
        save_to_db(imputation_lookup_df_int_rate, INT_RATE_MULTIVARIATE_LOOKUP)
        save_to_db(scaling_lookup_table, SCALING_LOOKUP_TABLE)
        save_to_db(one_hot_lookup_table, ONE_HOT_LOOKUP_TABLE)

        # save_to_db(lookup_df,'lookup_fintech_data_MET_P1_52-24625')
    else:
        df = load_csv_with_default_na_values(DATA_PATH)
        cleaned_df, lookup_df, imputation_lookup_df_int_rate,scaling_lookup_table ,one_hot_lookup_table= clean(df)
        save_csv(cleaned_df, CLEANED_CSV)
        save_csv(lookup_df, LOOKUP_CSV)
        save_csv(imputation_lookup_df_int_rate,INT_RATE_MULTIVARIATE_LOOKUP_CSV)
        save_csv(scaling_lookup_table,SCALING_LOOKUP_TABLE_CSV)
        save_csv(one_hot_lookup_table,ONE_HOT_LOOKUP_TABLE_CSV)

        save_to_db(cleaned_df,CLEANED_DATA_SET)
        save_to_db(lookup_df,LOOKUP)
        save_to_db(imputation_lookup_df_int_rate, INT_RATE_MULTIVARIATE_LOOKUP)
        save_to_db(scaling_lookup_table, SCALING_LOOKUP_TABLE)
        save_to_db(one_hot_lookup_table, ONE_HOT_LOOKUP_TABLE)

        # save_to_db(imputation_lookup_df_description, 'imputation_lookup_df_description')
        # save_to_db(imputation_lookup_df_emp_length, 'imputation_lookup_df_emp_length')
        # save_to_db(imputation_lookup_df_emp_title, 'imputation_lookup_df_emp_title')
        # save_csv(imputation_lookup_df_description,DESCRIPTION_MULTIVARIATE_LOOKUP_CSV)

    

    print('> Done!')



if __name__ == "__main__":
    main()
